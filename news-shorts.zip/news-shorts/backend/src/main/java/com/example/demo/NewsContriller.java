package com.example.demo;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.speech.v1.*;
import com.google.protobuf.ByteString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

@RestController
public class NewsController {

    @Value("${google.cloud.credentials.path}")
    private String googleCredentialsPath;

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam("duration") int duration, @RequestParam("language") String language) throws IOException {
        // Step 1: Transcribe audio to text
        String transcript = transcribeAudio(file, language);

        // Save the uploaded video file
        File inputVideoFile = new File("input_news_video.mp4");
        file.transferTo(inputVideoFile);

        // Step 2: Call Python script for keyword extraction, summarization, and video conversion
        String outputVideoPath = "vertical_news_video.mp4";
        callPythonScript(transcript, inputVideoFile.getPath(), outputVideoPath, duration);

        // Step 3: Return the path of the generated video
        return "{\"videoUrl\": \"" + outputVideoPath + "\"}";
    }

    private String transcribeAudio(MultipartFile file, String language) throws IOException {
        String languageCode = "en-US";
        if ("ko".equals(language)) {
            languageCode = "ko-KR";
        }

        SpeechSettings settings = SpeechSettings.newBuilder()
                .setCredentialsProvider(() -> GoogleCredentials.fromStream(new FileInputStream(googleCredentialsPath)))
                .build();

        try (SpeechClient speechClient = SpeechClient.create(settings)) {
            ByteString audioBytes = ByteString.readFrom(file.getInputStream());

            RecognitionAudio audio = RecognitionAudio.newBuilder().setContent(audioBytes).build();

            RecognitionConfig config = RecognitionConfig.newBuilder()
                    .setEncoding(RecognitionConfig.AudioEncoding.LINEAR16)
                    .setSampleRateHertz(16000)
                    .setLanguageCode(languageCode)
                    .build();

            List<SpeechRecognitionResult> results = speechClient.recognize(config, audio).getResultsList();

            StringBuilder transcript = new StringBuilder();
            for (SpeechRecognitionResult result : results) {
                SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
                transcript.append(alternative.getTranscript());
            }

            return transcript.toString();
        }
    }

    private void callPythonScript(String transcript, String inputVideoPath, String outputVideoPath, int duration) throws IOException {
        ProcessBuilder pb = new ProcessBuilder("python3", "process_news.py", transcript, inputVideoPath, outputVideoPath, String.valueOf(duration));
        pb.directory(new File(System.getProperty("user.dir"))); // Change this to your actual path if needed
        pb.redirectErrorStream(true);
        Process process = pb.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }

        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
