import sys
from transformers import pipeline
import cv2

def extract_keywords(text):
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize
    from collections import Counter
    import nltk
    nltk.download('punkt')
    nltk.download('stopwords')

    stop_words = set(stopwords.words('english')) | set(stopwords.words('korean'))
    words = word_tokenize(text)
    filtered_words = [word for word in words if word.isalnum() and word.lower() not in stop_words]
    keyword_freq = Counter(filtered_words)
    return keyword_freq.most_common(10)

def generate_summary(text, max_length):
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    summary = summarizer(text, max_length=max_length, min_length=int(max_length * 0.7), do_sample=False)
    return summary[0]['summary_text']

def convert_to_vertical(input_path, output_path):
    cap = cv2.VideoCapture(input_path)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, 20.0, (1080, 1920))

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        height, width, _ = frame.shape
        if width > height:
            new_height = int((width / 9) * 16)
            top = (new_height - height) // 2
            bottom = new_height - height - top
            frame = cv2.copyMakeBorder(frame, top, bottom, 0, 0, cv2.BORDER_CONSTANT, value=(0, 0, 0))
        else:
            new_width = int((height / 16) * 9)
            left = (new_width - width) // 2
            right = new_width - width - left
            frame = cv2.copyMakeBorder(frame, 0, 0, left, right, cv2.BORDER_CONSTANT, value=(0, 0, 0))

        out.write(frame)

