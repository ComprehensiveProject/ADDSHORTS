import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [file, setFile] = useState(null);
  const [duration, setDuration] = useState('60');
  const [language, setLanguage] = useState('ko');
  const [response, setResponse] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration);
    formData.append('language', language);

    try {
      const res = await axios.post('/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setResponse(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="App">
      <h1>Upload News Video</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="file">Choose video file:</label>
        <input type="file" id="file" name="file" onChange={handleFileChange} required />

        <label htmlFor="duration">Choose summary duration:</label>
        <select id="duration" name="duration" value={duration} onChange={(e) => setDuration(e.target.value)}>
          <option value="60">60 seconds</option>
          <option value="90">90 seconds</option>
        </select>

        <label htmlFor="language">Choose language:</label>
        <select id="language" name="language" value={language} onChange={(e) => setLanguage(e.target.value)}>
          <option value="ko">Korean</option>
          <option value="en">English</option>
        </select>

        <button type="submit">Upload</button>
      </form>
      {response && (
        <div>
          <h2>Generated video</h2>
          <video width="320" height="240" controls>
            <source src={response.videoUrl} type="video/mp4" />
          </video>
        </div>
      )}
    </div>
  );
}

export default App;
