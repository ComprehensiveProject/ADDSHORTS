import sys
import json
from konlpy.tag import Okt
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
import networkx as nx

def extract_sentences(text):
    okt = Okt()
    sentences = text.split('. ')
    tokenized_sentences = [" ".join(okt.nouns(sentence)) for sentence in sentences]
    return sentences, tokenized_sentences

def build_similarity_matrix(sentences):
    tfidf = TfidfVectorizer(tokenizer=lambda x: x.split(), lowercase=False)
    tfidf_matrix = tfidf.fit_transform(sentences)
    similarity_matrix = (tfidf_matrix * tfidf_matrix.T).toarray()
    return similarity_matrix

def summarize(text, top_n=5):
    sentences, tokenized_sentences = extract_sentences(text)
    similarity_matrix = build_similarity_matrix(tokenized_sentences)

    nx_graph = nx.from_numpy_array(similarity_matrix)
    scores = nx.pagerank(nx_graph)

    ranked_sentences = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)
    top_sentences = [sentence for score, sentence in ranked_sentences[:top_n]]
    return '. '.join(top_sentences)

if __name__ == "__main__":
    text = sys.argv[1]
    summary = summarize(text, top_n=5)  # 5개의 중요 문장을 추출
    print(json.dumps(summary))
