import sys
import json
from transformers import pipeline

def extract_keywords(text, top_n=5):
    summarizer = pipeline("summarization")
    summary = summarizer(text, max_length=150, min_length=40, do_sample=False)[0]['summary_text']

    ner = pipeline("ner", grouped_entities=True)
    entities = ner(summary)

    keywords = [entity['word'] for entity in entities[:top_n]]
    return keywords

if __name__ == "__main__":
    text = sys.argv[1]
    keywords = extract_keywords(text)
    print(json.dumps(keywords))
