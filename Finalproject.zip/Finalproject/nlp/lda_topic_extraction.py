import sys
import json
from konlpy.tag import Okt
from gensim import corpora, models

def extract_topics(text, num_topics=5):
    okt = Okt()
    sentences = text.split('. ')
    tokenized_sentences = [okt.nouns(sentence) for sentence in sentences]

    dictionary = corpora.Dictionary(tokenized_sentences)
    corpus = [dictionary.doc2bow(text) for text in tokenized_sentences]

    lda_model = models.LdaModel(corpus, num_topics=num_topics, id2word=dictionary, passes=15)

    topics = lda_model.print_topics(num_words=4)
    return [topic[1] for topic in topics]

if __name__ == "__main__":
    text = sys.argv[1]
    topics = extract_topics(text)
    print(json.dumps(topics))
