package com.example.myproject.controller;

import com.example.myproject.service.SpeechToTextService;
import com.example.myproject.service.TextAnalysisService;
import com.example.myproject.service.VideoEditorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/upload")
@Api(value = "Upload Controller", description = "REST APIs for uploading and processing videos")
public class UploadController {

    @Autowired
    private SpeechToTextService speechToTextService;

    @Autowired
    private TextAnalysisService textAnalysisService;

    @Autowired
    private VideoEditorService videoEditorService;

    @PostMapping
    @ApiOperation(value = "Upload video file and process it to create shorts", response = List.class)
    public ResponseEntity<List<String>> handleFileUpload(@RequestParam("file") MultipartFile file) throws Exception {
        String audioPath = speechToTextService.saveFile(file);
        String text = speechToTextService.convertSpeechToText(audioPath);
        String summarizedText = textAnalysisService.summarizeText(text);

        // 주제별로 텍스트를 분석하여 타임 범위를 생성합니다.
        Map<String, List<TimeRange>> topics = textAnalysisService.analyzeText(summarizedText);

        // 요약된 타임 범위를 사용하여 쇼츠 영상을 생성합니다.
        videoEditorService.createShorts(audioPath, topics, "outputDir");

        return ResponseEntity.ok(List.of(summarizedText));
    }
}
