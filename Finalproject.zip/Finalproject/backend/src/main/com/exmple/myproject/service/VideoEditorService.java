package com.example.myproject.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Comparator;

@Service
public class VideoEditorService {

    private final TextAnalysisService textAnalysisService;

    public VideoEditorService(TextAnalysisService textAnalysisService) {
        this.textAnalysisService = textAnalysisService;
    }

    public void createShorts(String videoPath, Map<String, List<TimeRange>> topics, String outputDir) throws IOException {
        int index = 0;
        for (Map.Entry<String, List<TimeRange>> entry : topics.entrySet()) {
            String topic = entry.getKey();
            List<TimeRange> ranges = entry.getValue();

            ranges.sort(Comparator.comparing(TimeRange::getStart));

            for (TimeRange range : ranges) {
                List<TimeRange> segments = splitTimeRange(range, 60);

                for (TimeRange segment : segments) {
                    String adjustedStart = adjustTime(segment.getStart(), -2);
                    String adjustedEnd = adjustTime(segment.getEnd(), 2);

                    String outputPath = outputDir + "/short_" + index++ + ".mp4";
                    String command = String.format("ffmpeg -i %s -ss %s -to %s -c copy %s",
                            videoPath, adjustedStart, adjustedEnd, outputPath);
                    ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
                    Process process = processBuilder.start();
                    try {
                        process.waitFor();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private List<TimeRange> splitTimeRange(TimeRange range, int maxDuration) {
        List<TimeRange> segments = new ArrayList<>();
        String start = range.getStart();
        String end = range.getEnd();
        int duration = calculateDuration(start, end);

        if (duration <= maxDuration) {
            segments.add(range);
        } else {
            int startSeconds = convertToSeconds(start);
            while (duration > 0) {
                int segmentDuration = Math.min(duration, maxDuration);
                String segmentEnd = convertToTime(startSeconds + segmentDuration);
                segments.add(new TimeRange(start, segmentEnd));
                startSeconds += segmentDuration;
                start = convertToTime(startSeconds);
                duration -= segmentDuration;
            }
        }

        return segments;
    }

    private int calculateDuration(String start, String end) {
        int startSeconds = convertToSeconds(start);
        int endSeconds = convertToSeconds(end);
        return endSeconds - startSeconds;
    }

    private int convertToSeconds(String time) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        int seconds = Integer.parseInt(parts[2]);
        return hours * 3600 + minutes * 60 + seconds;
    }

    private String convertToTime(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private String adjustTime(String time, int seconds) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        int secs = Integer.parseInt(parts[2]) + seconds;

        if (secs < 0) {
            secs += 60;
            minutes -= 1;
        } else if (secs >= 60) {
            secs -= 60;
            minutes += 1;
        }

        if (minutes < 0) {
            minutes += 60;
            hours -= 1;
        } else if (minutes >= 60) {
            minutes -= 60;
            hours += 1;
        }

        return String.format("%02d:%02d:%02d", hours, minutes, secs);
    }
}
