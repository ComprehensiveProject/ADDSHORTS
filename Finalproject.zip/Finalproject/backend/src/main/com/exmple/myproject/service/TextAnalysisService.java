package com.example.myproject.service;

import com.example.myproject.model.TimeRange;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TextAnalysisService {

    public String summarizeText(String text) throws Exception {
        ProcessBuilder processBuilder = new ProcessBuilder("python3", "nlp/text_summary.py", text);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            return reader.lines().collect(Collectors.joining());
        }
    }

    public Map<String, List<TimeRange>> analyzeText(String text) {
        Map<String, List<TimeRange>> topicTimeRanges = new HashMap<>();
        List<String> keywords = new ArrayList<>();

        // TF-IDF를 사용하여 키워드 추출
        keywords.addAll(extractKeywordsUsingTFIDF(text));

        // LDA를 사용하여 주제 추출
        keywords.addAll(extractTopicsUsingLDA(text));

        // BERT를 사용하여 문맥 키워드 추출
        keywords.addAll(extractKeywordsUsingBERT(text));

        // 중복 키워드 제거
        keywords = keywords.stream().distinct().collect(Collectors.toList());

        for (String keyword : keywords) {
            List<TimeRange> timeRanges = extractTimeRangesForKeyword(keyword, text);
            topicTimeRanges.put(keyword, timeRanges);
        }

        return topicTimeRanges;
    }

    private List<String> extractKeywordsUsingTFIDF(String text) {
        List<String> words = tokenizeText(text);
        Map<String, Double> tfidfScores = calculateTFIDF(words);

        return tfidfScores.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private List<String> tokenizeText(String text) {
        List<String> tokens = new ArrayList<>();
        try (KoreanAnalyzer analyzer = new KoreanAnalyzer()) {
            StandardTokenizer tokenizer = new StandardTokenizer();
            tokenizer.setReader(new StringReader(text));
            tokenizer.reset();

            CharTermAttribute attr = tokenizer.addAttribute(CharTermAttribute.class);
            while (tokenizer.incrementToken()) {
                tokens.add(attr.toString());
            }
            tokenizer.end();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tokens;
    }

    private Map<String, Double> calculateTFIDF(List<String> words) {
        Map<String, Double> tfidfScores = new HashMap<>();
        Map<String, Integer> termFrequency = new HashMap<>();
        int totalTerms = words.size();

        for (String word : words) {
            termFrequency.put(word, termFrequency.getOrDefault(word, 0) + 1);
        }

        for (Map.Entry<String, Integer> entry : termFrequency.entrySet()) {
            String word = entry.getKey();
            int tf = entry.getValue();
            double idf = Math.log((double) totalTerms / (1 + tf));
            double tfidf = tf * idf;
            tfidfScores.put(word, tfidf);
        }

        return tfidfScores;
    }

    private List<String> extractTopicsUsingLDA(String text) {
        ProcessBuilder processBuilder = new ProcessBuilder("python3", "nlp/lda_topic_extraction.py", text);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            return reader.lines().collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    private List<String> extractKeywordsUsingBERT(String text) {
        ProcessBuilder processBuilder = new ProcessBuilder("python3", "nlp/bert_keyword_extraction.py", text);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            return reader.lines().collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    private List<TimeRange> extractTimeRangesForKeyword(String keyword, String text) {
        List<TimeRange> timeRanges = new ArrayList<>();
        String[] sentences = text.split("\\. ");
        int startTime = 0;

        for (String sentence : sentences) {
            if (sentence.contains(keyword)) {
                int endTime = startTime + 10;
                timeRanges.add(new TimeRange(formatTime(startTime), formatTime(endTime)));
            }
            startTime += 10;
        }

        return timeRanges;
    }

    private String formatTime(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
